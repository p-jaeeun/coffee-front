export class Validation {
  constructor() {}
  checkGenderInput() {}
}
